/Users/ivanyalov/Projects/hkust/isdn5230-healthcare/project/bed-prototype/.cache/arduino/diagnostics-build/core/WMath.cpp.o: \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/WMath.cpp
