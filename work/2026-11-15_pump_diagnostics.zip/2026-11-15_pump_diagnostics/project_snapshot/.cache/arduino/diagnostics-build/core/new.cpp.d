/Users/ivanyalov/Projects/hkust/isdn5230-healthcare/project/bed-prototype/.cache/arduino/diagnostics-build/core/new.cpp.o: \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/new.cpp \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/new.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/new
