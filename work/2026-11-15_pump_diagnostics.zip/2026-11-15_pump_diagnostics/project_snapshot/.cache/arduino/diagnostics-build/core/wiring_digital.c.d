/Users/ivanyalov/Projects/hkust/isdn5230-healthcare/project/bed-prototype/.cache/arduino/diagnostics-build/core/wiring_digital.c.o: \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/wiring_digital.c \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/wiring_private.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/Arduino.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/binary.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/variants/standard/pins_arduino.h
