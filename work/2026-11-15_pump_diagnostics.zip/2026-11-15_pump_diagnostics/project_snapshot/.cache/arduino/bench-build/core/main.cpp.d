/Users/ivanyalov/Projects/hkust/isdn5230-healthcare/project/bed-prototype/.cache/arduino/bench-build/core/main.cpp.o: \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/main.cpp \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/Arduino.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/binary.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/WCharacter.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/WString.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/HardwareSerial.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/Stream.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/Print.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/Printable.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/USBAPI.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/cores/arduino/Arduino.h \
 /Users/ivanyalov/Library/Arduino15/packages/arduino/hardware/avr/1.8.8/variants/standard/pins_arduino.h
