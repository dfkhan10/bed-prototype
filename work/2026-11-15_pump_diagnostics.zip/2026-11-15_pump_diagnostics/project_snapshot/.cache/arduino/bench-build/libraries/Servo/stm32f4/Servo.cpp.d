/Users/ivanyalov/Projects/hkust/isdn5230-healthcare/project/bed-prototype/.cache/arduino/bench-build/libraries/Servo/stm32f4/Servo.cpp.o: \
 /Users/ivanyalov/Documents/Arduino/libraries/Servo/src/stm32f4/Servo.cpp
