/Users/ivanyalov/Projects/hkust/isdn5230-healthcare/project/bed-prototype/.cache/arduino/bench-build/libraries/Servo/sam/Servo.cpp.o: \
 /Users/ivanyalov/Documents/Arduino/libraries/Servo/src/sam/Servo.cpp
