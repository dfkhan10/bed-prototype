/Users/ivanyalov/Projects/hkust/isdn5230-healthcare/project/bed-prototype/.cache/arduino/bench-build/libraries/Servo/xmc/Servo.cpp.o: \
 /Users/ivanyalov/Documents/Arduino/libraries/Servo/src/xmc/Servo.cpp
